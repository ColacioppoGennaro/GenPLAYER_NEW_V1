package com.genaro.radiomp3.ui

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class CoverViewModel : ViewModel() {
    private val _artwork = MutableStateFlow<Bitmap?>(null)
    val artwork: StateFlow<Bitmap?> = _artwork

    fun setArtwork(bmp: Bitmap?) {
        _artwork.value = bmp
    }

    fun getArtwork(): Bitmap? = _artwork.value
}
