package com.genaro.radiomp3.ui

import androidx.lifecycle.ViewModel

class UiStateViewModel : ViewModel() {
    // Tracks whether UI initialization (like first artwork load) has been done
    // This survives Activity recreation during rotation
    var uiInitializedOnce = false
}
